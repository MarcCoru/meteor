| model                     |   avg_ranks | wcx-test   |   wcx-pvalue |   anthroprotect |   denethor |   dfc2020 |   eurosat |   floatingobjects |   nwpuresisc45 |
|:--------------------------|------------:|:-----------|-------------:|----------------:|-----------:|----------:|----------:|------------------:|---------------:|
| meteor                    |         1.5 |            |              |            83.7 |       75.6 |      87.7 |      60.9 |              90.8 |           57.4 |
| SSLTransformerRS-resnet50 |         2.5 |            |          0.2 |            90.7 |       65.5 |      76.3 |      59.7 |              78.9 |           52.1 |
| SSLTransformerRS-swin     |         2.7 | *          |          0.1 |            72.9 |       68.6 |      80.1 |      56.4 |              91.2 |           45.3 |
| SSLTransformerRS-resnet18 |         3.3 | *          |          0.1 |            88.7 |       67.0 |      63.6 |      55.6 |              65.4 |           49.5 |
